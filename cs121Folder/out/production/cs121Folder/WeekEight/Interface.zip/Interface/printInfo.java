package WeekEight.Interface;

public interface printInfo {
    String printName();
}
