package Project_2;

public class Main {

    public static void main(String[] args){

        Pokemon_Selection newGame = new Pokemon_Selection();
               newGame.assignPokemon();


    }

}
